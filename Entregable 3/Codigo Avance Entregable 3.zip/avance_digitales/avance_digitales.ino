#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

// --- CONFIGURACIÓN DE LA PANTALLA OLED SH1106 ---
#define i2c_Address 0x3c 
#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 64 
#define OLED_RESET -1   
Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- ASIGNACIÓN DE PINES PARA LOS LEDS DE ESTADO ---
#define LED_LISTO    10  // LED Verde: Indicador de sistema vacío / En espera de datos
#define LED_OVERFLOW  11  // LED Rojo: Indicador de desbordamiento de memoria (Alarma visual)
#define LED_INGRESO  12  // LED Amarillo: Indicador de edición activa / Buffer con datos
#define LED_ENVIADO   13  // LED Azul: Indicador de transmisión activa hacia el bus UART

// --- CONFIGURACIÓN DEL TECLADO MATRICIAL 4x4 ---
const int FILAS = 4;
const int COLUMNAS = 4;

int pinesFilas[FILAS]       = {2, 3, 4, 5};   // Pines físicos asignados para las filas
int pinesColumnas[COLUMNAS] = {6, 7, 8, 9};   // Pines físicos asignados para las columnas

char teclas[FILAS][COLUMNAS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

// --- BANCO DE REGISTROS / BUFFER DE ALMACENAMIENTO (RAM) ---
char bufferComando[5]; // Capacidad limitada a un máximo de 4 caracteres útiles más terminador
int indiceBuffer = 0;   

// Definición de estados para la Máquina de Estados Finita (FSM)
enum EstadosFSM { IDLE, RECEIVE, STORE, SEND, CLR, ERROR_OLED };
EstadosFSM estadoActual = IDLE;

// Bandera de control para la sincronización de flancos mecánicos (Debounce)
bool teclaLiberada = true; 

// Prototipos de funciones globales
char escanearTeclado();
void cargarMacro(const char* textoMacro);
void ejecutarResetMemoria();
void dibujarTrianguloPeligro(int x, int y);

void setup() {
  // Inicialización del periférico serie para la transmisión de comandos AT y telemetría de depuración
  Serial.begin(9600);
  
  // Configuración de los pines de la interfaz de LEDs como salidas digitales
  pinMode(LED_LISTO, OUTPUT);
  pinMode(LED_INGRESO, OUTPUT);
  pinMode(LED_ENVIADO, OUTPUT);
  pinMode(LED_OVERFLOW, OUTPUT);
  
  // Inicialización del estado eléctrico de los LEDs en nivel bajo
  digitalWrite(LED_LISTO, LOW);
  digitalWrite(LED_INGRESO, LOW);
  digitalWrite(LED_ENVIADO, LOW);
  digitalWrite(LED_OVERFLOW, LOW);
  
  // Inicialización del hardware del controlador de la pantalla OLED SH1106
  delay(500);
  display.begin(i2c_Address, true);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  
  // Despliegue de la rutina visual de inicio de sistema
  display.setCursor(0, 10);
  display.println("Sist. Comando AT");
  display.setCursor(0, 30);
  display.println("Listo...");
  display.display();
  delay(1500);
  
  // Ejecución de la rutina de limpieza inicial y direccionamiento de pines del teclado
  ejecutarResetMemoria(); 
}

void loop() {
  // Adquisición cíclica del estado físico del teclado matricial
  char teclaPresionada = escanearTeclado();
  
  // Verificación del flanco de subida (liberación del interruptor)
  if (teclaPresionada == '\0') {
    teclaLiberada = true;
  }
  
  // Ejecución asíncrona de la Máquina de Estados Finita (FSM)
  switch (estadoActual) {
    
    case IDLE: 
      // Control de los indicadores HMI según el nivel de llenado del búfer de datos
      if (indiceBuffer == 0) {
        digitalWrite(LED_LISTO, HIGH);    // Búfer vacío: Estado en espera puro (Verde ON)
        digitalWrite(LED_INGRESO, LOW);   // LED Amarillo OFF
      } else {
        digitalWrite(LED_LISTO, LOW);     // LED Verde OFF
        digitalWrite(LED_INGRESO, HIGH);  // Búfer con datos: Estado de edición activo (Amarillo ON)
      }
      digitalWrite(LED_ENVIADO, LOW);
      digitalWrite(LED_OVERFLOW, LOW);

      // Evaluación del cambio de estado al detectar una pulsación válida y única
      if (teclaPresionada != '\0' && teclaLiberada == true) {
        teclaLiberada = false; 
        estadoActual = RECEIVE;
      }
      break;
      
    case RECEIVE: 
      // Decodificación y enrutamiento del carácter según la tabla de funciones
      if (teclaPresionada == '*') estadoActual = SEND; 
      else if (teclaPresionada == '#') estadoActual = CLR;  
      else estadoActual = STORE; 
      break;
      
    case STORE: 
      // Inhibición temporal del indicador estático de espera
      digitalWrite(LED_LISTO, LOW); 
      
      // Decodificación de cadenas de comandos preestablecidos (Macros)
      if (teclaPresionada == 'A') {
        cargarMacro("BAUD"); 
      } 
      else if (teclaPresionada == 'B') {
        cargarMacro("MODE"); 
      } 
      else if (teclaPresionada == 'C') {
        cargarMacro("CHAN"); 
      } 
      else if (teclaPresionada == 'D') {
        estadoActual = IDLE; 
      } 
      else {
        // Validación del límite físico del búfer de memoria (Límite = 4 caracteres)
        if (indiceBuffer < 4) { 
          bufferComando[indiceBuffer] = teclaPresionada;
          indiceBuffer++;
          bufferComando[indiceBuffer] = '\0'; // Inserción forzada del terminador nulo
          
          // Telemetría serie discreta: Transmisión inmediata del carácter procesado individualmente
          Serial.println(teclaPresionada); 
          
          // Refresco y actualización de los caracteres en la interfaz OLED
          display.clearDisplay();
          display.setCursor(0, 10);
          display.println("Sist. Listo");
          display.setCursor(0, 30);
          display.print("Ingrese Comm: ");
          display.print(bufferComando);
          display.display();
          
          // Lazo síncrono de retención para evitar dobles lecturas del mismo carácter
          while(escanearTeclado() != '\0'); 
          
          estadoActual = IDLE;
        } else {
          estadoActual = ERROR_OLED; // Transición por desbordamiento de memoria (Excepción de rango)
        }
      }
      break;
      
    case SEND: 
      // Actualización de la interfaz HMI para el proceso de transmisión UART (Azul ON)
      digitalWrite(LED_LISTO, LOW);
      digitalWrite(LED_INGRESO, LOW);
      digitalWrite(LED_OVERFLOW, LOW);
      digitalWrite(LED_ENVIADO, HIGH); 
      
      // Despliegue visual del comando saliente e indicación para el monitoreo externo
      display.clearDisplay();
      display.setCursor(0, 10);
      display.println("TX UART MODEM");
      display.setCursor(0, 30);
      display.print("AT+");
      display.println(bufferComando);
      display.setCursor(0, 50);
      display.print("- Observar monitor -"); 
      display.display();
      
      // Envío del comando estructurado hacia el puerto serie físico
      Serial.print("AT+");
      Serial.println(bufferComando);
      
      // Ventana de tiempo fija para asegurar la sustentación visual de los datos en pantalla
      delay(2000); 
      digitalWrite(LED_ENVIADO, LOW); 
      
      estadoActual = CLR; 
      break;
      
    case CLR: 
      // Llamada procedimental para el vaciado de los registros de almacenamiento
      ejecutarResetMemoria();
      break;
      
    case ERROR_OLED: 
      // Desactivación de indicadores operacionales ordinarios
      digitalWrite(LED_LISTO, LOW);
      digitalWrite(LED_INGRESO, LOW);
      digitalWrite(LED_ENVIADO, LOW);
      
      // Reporte de excepción asíncrono dirigido hacia la terminal serie
      Serial.println("ERROR: Overflow - Limite superado");
      
      // Despliegue del mensaje crítico de error e indicación de límite superado en pantalla OLED
      display.clearDisplay();
      display.setCursor(0, 10);
      display.println("ERROR: Overflow ");
      display.setCursor(0, 25);
      display.println("Limite superado"); 
      
      // Renderizado del icono gráfico de peligro (Coordenadas de origen X=54, Y=40)
      dibujarTrianguloPeligro(54, 40);
      display.display();
      
      // Ejecución del bucle temporizado para el destello intermitente de la alarma visual (Rojo parpadeante, 1.5s total)
      for (int i = 0; i < 5; i++) {
        digitalWrite(LED_OVERFLOW, HIGH); 
        delay(150);                 
        digitalWrite(LED_OVERFLOW, LOW);  
        delay(150);                 
      }
      
      // Restauración de la interfaz gráfica a la última configuración válida almacenada en el búfer
      display.clearDisplay();
      display.setCursor(0, 10);
      display.println("Sist. Listo");
      display.setCursor(0, 30);
      display.print("Ingrese Comm: ");
      display.print(bufferComando);
      display.display();
      
      estadoActual = IDLE;
      break;
  }
}

// Algoritmo procedimental para el escaneo matricial por barrido secuencial de líneas
char escanearTeclado() {
  for (int f = 0; f < FILAS; f++) {
    // Activación secuencial por nivel lógico bajo en filas
    digitalWrite(pinesFilas[f], LOW); 
    
    for (int c = 0; c < COLUMNAS; c++) {
      // Detección de continuidad en la columna activa mediante resistencia Pull-Up interna
      if (digitalRead(pinesColumnas[c]) == LOW) {
        delay(20); // Retraso para la amortiguación de transitorios mecánicos (Debounce)
        if (digitalRead(pinesColumnas[c]) == LOW) {
          digitalWrite(pinesFilas[f], HIGH); // Restauración de la línea de fila
          return teclas[f][c];               // Retorno inmediato del carácter decodificado
        }
      }
    }
    // Restauración de la línea de fila en caso de no registrarse evento físico
    digitalWrite(pinesFilas[f], HIGH); 
  }
  return '\0'; // Retorno por defecto ante la ausencia de pulsaciones
}

// Subrutina para la copia y carga directa de strings desde memoria flash al búfer operativo
void cargarMacro(const char* textoMacro) {
  indiceBuffer = 0; 
  while (*textoMacro && indiceBuffer < 4) {
    bufferComando[indiceBuffer] = *textoMacro;
    textoMacro++;
    indiceBuffer++;
  }
  bufferComando[indiceBuffer] = '\0'; 
  
  // Sincronización gráfica del comando cargado en el display OLED
  display.clearDisplay();
  display.setCursor(0, 10);
  display.println("Sist. Listo");
  display.setCursor(0, 30);
  display.print("Ingrese Comm: ");
  display.print(bufferComando);
  display.display();
  
  // Retención síncrona hasta la liberación del pulsador asociado a la macro
  while(escanearTeclado() != '\0');
  
  estadoActual = IDLE;
}

// Subrutina de inicialización de E/S y vaciado estructural del arreglo de caracteres
void ejecutarResetMemoria() {
  // Limpieza total del búfer mediante asignación de caracteres nulos
  indiceBuffer = 0;
  for (int i = 0; i < 5; i++) {
    bufferComando[i] = '\0'; 
  }
  
  // Direccionamiento eléctrico inicial de pines de salida para las líneas de fila
  for (int i = 0; i < FILAS; i++) {
    pinMode(pinesFilas[i], OUTPUT);
    digitalWrite(pinesFilas[i], HIGH);
  }
  // Direccionamiento eléctrico inicial de pines de entrada con Pull-Up para las líneas de columna
  for (int j = 0; j < COLUMNAS; j++) {
    pinMode(pinesColumnas[j], INPUT_PULLUP);
  }
  
  // Inicialización de la pantalla de edición operativa en estado vacío
  display.clearDisplay();
  display.setCursor(0, 10);
  display.println("Sist. Listo");
  display.setCursor(0, 30);
  display.print("Ingrese Comm: ");
  display.display();
  
  // Configuración estática de los LEDs para el estado inicial de reposo libre (Verde ON, el resto OFF)
  digitalWrite(LED_LISTO, HIGH);
  digitalWrite(LED_INGRESO, LOW);
  digitalWrite(LED_ENVIADO, LOW);
  digitalWrite(LED_OVERFLOW, LOW);
  
  estadoActual = IDLE;
}

// Subrutina gráfica encargada de trazar un triángulo de advertencia con un signo de exclamación interno
void dibujarTrianguloPeligro(int x, int y) {
  // Dimensionamiento matemático: base de 20 píxeles, altura de 18 píxeles
  display.drawLine(x, y + 18, x + 20, y + 18, SH110X_WHITE); // Segmento inferior (Base)
  display.drawLine(x, y + 18, x + 10, y,      SH110X_WHITE); // Segmento lateral izquierdo
  display.drawLine(x + 20, y + 18, x + 10, y, SH110X_WHITE); // Segmento lateral derecho
  
  // Trazado del signo de exclamación interno mediante puntos fijos ordenados
  display.drawPixel(x + 10, y + 5,  SH110X_WHITE); // Cuerpo superior del signo
  display.drawPixel(x + 10, y + 6,  SH110X_WHITE);
  display.drawPixel(x + 10, y + 7,  SH110X_WHITE);
  display.drawPixel(x + 10, y + 8,  SH110X_WHITE);
  display.drawPixel(x + 10, y + 9,  SH110X_WHITE);
  display.drawPixel(x + 10, y + 10, SH110X_WHITE);
  display.drawPixel(x + 10, y + 11, SH110X_WHITE);
  
  display.drawPixel(x + 10, y + 14, SH110X_WHITE); // Punto inferior del signo
  display.drawPixel(x + 10, y + 15, SH110X_WHITE);
}