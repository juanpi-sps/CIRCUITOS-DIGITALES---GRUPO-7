#include <SoftwareSerial.h>
#include <Keypad.h> // Es necesario instalar esta librería desde el Gestor de Librerías

// Configuración del Teclado Matricial 4x4
const byte FILAS = 4; 
const byte COLUMNAS = 4; 

// Definición del mapa de teclas
char mapaTeclas[FILAS][COLUMNAS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

// Pines de conexión del Arduino (Filas: 11, 10, 9, 8 | Columnas: 7, 6, 5, 4)
byte pinesFilas[FILAS] = {11, 10, 9, 8}; 
byte pinesColumnas[COLUMNAS] = {7, 6, 5, 4}; 

// Inicialización del teclado
Keypad teclado = Keypad(makeKeymap(mapaTeclas), pinesFilas, pinesColumnas, FILAS, COLUMNAS);

// Crear objeto de software serial para comunicarse con SIM800L (Tx=3, Rx=2)
SoftwareSerial mySerial(3, 2);  

void setup() {
  // Comunicación con el Monitor Serie (PC)
  Serial.begin(9600);

  // Comunicación con el módulo SIM800L
  mySerial.begin(9600);

  Serial.println("Inicializando...");
  delay(1000);

  // Pruebas de inicio de tu código original
  mySerial.println("AT");        
  updateSerial();
  mySerial.println("AT+CSQ");    
  updateSerial();
  mySerial.println("AT+CCID");   
  updateSerial();
  mySerial.println("AT+CREG?");  
  updateSerial();
  
  Serial.println("Sistema Listo. Presiona una tecla para enviar comandos AT.");
}

void loop() {
  // Leer la tecla presionada
  char tecla = teclado.getKey();
  
  if (tecla) {
    Serial.print("Teclas presionada: ");
    Serial.println(tecla);
    
    // Macros de comandos AT asignados a las teclas
    switch (tecla) {
      case '1':
        Serial.println("Macro: Verificando estado del módulo...");
        mySerial.println("AT");
        break;
        
      case '2':
        Serial.println("Macro: Comprobando calidad de señal...");
        mySerial.println("AT+CSQ");
        break;
        
      case '3':
        Serial.println("Macro: Comprobando red registrada...");
        mySerial.println("AT+CREG?");
        break;
        
      case 'A':
        Serial.println("Macro: Responder llamada entrante...");
        mySerial.println("ATA");
        break;
        
      case 'B':
        Serial.println("Macro: Colgar/Cancelar llamada...");
        mySerial.println("ATH");
        break;
        
      case 'D':
        Serial.println("Macro: Configurando modo Texto para SMS...");
        mySerial.println("AT+CMGF=1");
        break;

      case 'C':
        // Ejemplo de envío de SMS (Recuerda cambiar el número de teléfono)
        Serial.println("Macro: Enviando SMS de prueba...");
        mySerial.println("AT+CMGF=1"); // Modo texto
        delay(200);
        mySerial.println("AT+CMGS=\"+51993098712\""); // Reemplaza con el número real
        delay(200);
        mySerial.print("m ensaje."); // Mensaje
        delay(200);
        mySerial.write(26); // Código ASCII del comando Ctrl+Z para enviar el SMS
        break;
        
      default:
        Serial.println("Tecla sin comando AT asignado.");
        break;
    }
  }

  // Mantener la comunicación bidireccional activa
  updateSerial();
}

void updateSerial() {
  delay(100); // Reducido un poco para mejorar la respuesta del teclado
  while (Serial.available()) {
    mySerial.write(Serial.read());  
  }
  while (mySerial.available()) {
    Serial.write(mySerial.read());  
  }
}